package lab;

public class InvalidNumberFormat extends Exception
{
    public InvalidNumberFormat(String what)
    {
        super(what);
    }
}
