package lab;

public interface CarInformation
{
    String getInformation();
}
